# This is our final project folder
# We have two .py files two scrape data from autos.nj.com and twitter respectively.
# We save the data from twitter in json files, and data from autos.nj.com in csv files.
